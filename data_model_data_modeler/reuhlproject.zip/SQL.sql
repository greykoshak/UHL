select * from "global" g 

select * from "global" g, dr_equipment_type det 
where g.dr_eq_type_id = det.dr_equipment_type_id and det.type_name = 'Stick'--g.dr_eq_type_id = 1

select * from "global" g, dr_equipment_type ty
where g.dr_eq_type_id = ty.dr_equipment_type_id --and det.type_name = 'Stick'

select * from "global" g, dr_equipment_type ty, dr_stick ds 
where g.dr_eq_type_id = ty.dr_equipment_type_id and g.dr_eq_id = ds.dr_eq_id and ty.type_name = 'Stick'

DROP TABLE IF EXISTS dr_stick;

CREATE TABLE dr_stick (
    dr_eq_id   SERIAL,
    stick_name VARCHAR(50),
    -- CONSTRAINT dr_stick_pkey PRIMARY KEY (dr_eq_id),
    CONSTRAINT fk_customer FOREIGN KEY(dr_eq_id) REFERENCES dr_equipment_type(dr_equipment_type_ID)
);