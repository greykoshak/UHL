
CREATE TABLE dr_equipment_type (
    dr_equipment_type_ID   SERIAL,
    type_name VARCHAR(50),
    CONSTRAINT dr_equipment_type_pkey PRIMARY KEY (dr_equipment_type_ID)
);

CREATE TABLE dr_skate (
    dr_eq_id   SERIAL,
    scate_name VARCHAR(50),
    CONSTRAINT dr_skate_pkey PRIMARY KEY (dr_eq_id)
);

CREATE TABLE dr_stick (
    dr_eq_id   SERIAL,
    stick_name VARCHAR(50),
    -- CONSTRAINT dr_stick_pkey PRIMARY KEY (dr_eq_id),
    CONSTRAINT fk_dr_equipment_type FOREIGN KEY(dr_eq_id) REFERENCES dr_equipment_type(dr_equipment_type_ID)
);

CREATE TABLE global (
    global_id   SERIAL,
    dr_eq_id SERIAL,
    dr_eq_type_id SERIAL,
    CONSTRAINT global_pkey PRIMARY KEY (global_id)
);


INSERT INTO dr_equipment_type (dr_equipment_type_id, type_name) VALUES(1, 'Stick');
INSERT INTO dr_equipment_type (dr_equipment_type_id, type_name) VALUES(2, 'Skate');

INSERT INTO dr_stick (dr_eq_id, stick_name) VALUES(1, 'Stick_1');
INSERT INTO dr_stick (dr_eq_id, stick_name) VALUES(2, 'Stick_2');

INSERT INTO dr_skate (dr_eq_id, scate_name) VALUES(1, 'Skate_1');
INSERT INTO dr_skate (dr_eq_id, scate_name) VALUES(2, 'Skate_2');

INSERT INTO "global" (global_id, dr_eq_id, dr_eq_type_id) VALUES(1, 1, 1);
INSERT INTO "global" (global_id, dr_eq_id, dr_eq_type_id) VALUES(2, 1, 2);
INSERT INTO "global" (global_id, dr_eq_id, dr_eq_type_id) VALUES(3, 2, 1);
INSERT INTO "global" (global_id, dr_eq_id, dr_eq_type_id) VALUES(4, 2, 2);
